import React, { useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Settings, Book, Camera, Type, Volume2, ChevronLeft, List, FileText, Plus, Image as ImageIcon, Zap, Maximize } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'library' | 'read' | 'scan' | 'settings'>('read');
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1.5);
  const [showFontMenu, setShowFontMenu] = useState(false);

  return (
    <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-4 font-sans sm:py-10">
      {/* Phone Mockup Container */}
      <div className="w-full max-w-[400px] h-[800px] bg-white rounded-[3rem] shadow-2xl overflow-hidden relative border-[8px] border-gray-900 flex flex-col">
        
        {/* Top Status Bar (Fake iOS) */}
        <div className="h-7 w-full absolute top-0 z-50 flex justify-between items-center px-7 pt-2 pointer-events-none">
          <span className="text-[11px] font-bold text-black/80 tracking-wide">9:41</span>
          <div className="flex gap-1.5 items-center">
            <div className="w-4 h-2.5 bg-black/80 rounded-[2px] relative">
              <div className="absolute right-[-3px] top-[2px] w-[2px] h-[6px] bg-black/80 rounded-r-sm"></div>
            </div>
          </div>
        </div>

        {/* Dynamic Island / Notch Space */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-gray-900 rounded-b-3xl z-50 shadow-sm"></div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden relative bg-white">
          {activeTab === 'library' && <LibraryView />}
          {activeTab === 'read' && <ReadView isPlaying={isPlaying} setIsPlaying={setIsPlaying} showFontMenu={showFontMenu} setShowFontMenu={setShowFontMenu} />}
          {activeTab === 'scan' && <ScanView />}
          {activeTab === 'settings' && <SettingsView speed={speed} setSpeed={setSpeed} />}
        </div>

        {/* Bottom Navigation */}
        <div className="bg-white/90 backdrop-blur-md border-t border-gray-100 flex justify-around items-center p-3 pb-6 relative z-50">
          <NavItem icon={<Book />} label="Library" isActive={activeTab === 'library'} onClick={() => setActiveTab('library')} />
          <NavItem icon={<FileText />} label="Read" isActive={activeTab === 'read'} onClick={() => setActiveTab('read')} />
          <NavItem icon={<Camera />} label="Scan" isActive={activeTab === 'scan'} onClick={() => setActiveTab('scan')} />
          <NavItem icon={<Settings />} label="Settings" isActive={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />
        </div>
      </div>
    </div>
  );
}

// Subcomponents

const NavItem = ({ icon, label, isActive, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1.5 p-2 transition-colors ${isActive ? 'text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
  >
    <div className={`transition-transform duration-200 ${isActive ? 'scale-110 drop-shadow-sm' : ''}`}>
      {React.cloneElement(icon, { className: 'w-6 h-6', strokeWidth: isActive ? 2.5 : 2 })}
    </div>
    <span className={`text-[10px] font-medium ${isActive ? 'font-bold' : ''}`}>{label}</span>
  </button>
);

const ReadView = ({ isPlaying, setIsPlaying, showFontMenu, setShowFontMenu }: any) => (
  <div className="flex flex-col h-full bg-[#FDFBF7] relative pt-8">
    {/* Header */}
    <div className="flex justify-between items-center p-4">
      <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"><ChevronLeft /></button>
      <span className="font-semibold text-sm tracking-wide text-gray-800">Adventure I</span>
      <div className="flex gap-1">
        <button 
          onClick={() => setShowFontMenu(!showFontMenu)} 
          className={`p-2 rounded-full transition-colors ${showFontMenu ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:bg-gray-100'}`}
        >
          <Type size={20} />
        </button>
        <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"><List size={20} /></button>
      </div>
    </div>

    {/* Font Menu Dropdown */}
    {showFontMenu && (
       <div className="absolute top-16 right-4 bg-white shadow-2xl rounded-3xl p-5 w-72 z-20 border border-gray-100 animate-in fade-in zoom-in duration-200">
          <div className="flex items-center justify-between mb-5">
             <span className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Font Size</span>
             <div className="flex items-center gap-2 bg-gray-50 p-1 rounded-full">
                <button className="w-10 h-10 rounded-full hover:bg-white hover:shadow-sm flex items-center justify-center font-serif text-sm transition-all">A</button>
                <button className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center font-serif text-lg transition-all">A</button>
             </div>
          </div>
          <div className="flex justify-between items-center">
             <span className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Theme</span>
             <div className="flex gap-3">
                <button className="w-8 h-8 rounded-full bg-white border-2 border-blue-500 shadow-sm"></button>
                <button className="w-8 h-8 rounded-full bg-[#F4ECD8] border border-gray-300 shadow-sm"></button>
                <button className="w-8 h-8 rounded-full bg-gray-900 border border-gray-900 shadow-sm"></button>
             </div>
          </div>
       </div>
    )}

    {/* Text Content */}
    <div className="flex-1 overflow-y-auto px-6 pb-48 font-serif scroll-smooth">
      <h1 className="text-2xl font-bold text-center mb-8 mt-4 tracking-widest text-gray-900 font-sans">A SCANDAL IN BOHEMIA</h1>
      <p className="text-lg leading-relaxed text-gray-800 mb-6 text-justify indent-8 first-letter:text-5xl first-letter:font-bold first-letter:float-left first-letter:mr-2 first-letter:-mt-1">
        To Sherlock Holmes she is always the woman. I have seldom heard him mention her under any other name. In his eyes she eclipses and predominates the whole of her sex. It was not that he felt any emotion akin to love for Irene Adler. All emotions, and that one particularly, were abhorrent to his cold, precise but admirably balanced mind.
      </p>
      <p className="text-lg leading-relaxed text-gray-800 mb-6 text-justify indent-8">
        He was, I take it, the most perfect reasoning and observing machine that the world has seen, but as a lover he would have placed himself in a false position. He never spoke of the softer passions, save with a gibe and a sneer. They were admirable things for the observer—excellent for drawing the veil from men's motives and actions.
      </p>
      <p className="text-lg leading-relaxed text-gray-800 mb-6 text-justify indent-8">
        But for the trained reasoner to admit such intrusions into his own delicate and finely adjusted temperament was to introduce a distracting factor which might throw a doubt upon all his mental results.
      </p>
    </div>

    {/* Bottom Player */}
    <div className="absolute bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl rounded-t-[2.5rem] shadow-[0_-10px_40px_rgba(0,0,0,0.08)] p-6 z-10 border-t border-white">
       <div className="flex items-center gap-3 mb-6">
          <span className="text-xs font-semibold text-gray-400 w-10 text-right">00:16</span>
          <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden relative cursor-pointer group">
             <div className="absolute top-0 left-0 h-full bg-blue-600 w-1/4 rounded-full"></div>
             {/* Scrubber thumb handle on hover */}
             <div className="absolute top-1/2 -translate-y-1/2 left-1/4 -ml-1.5 w-3 h-3 bg-white border-2 border-blue-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </div>
          <span className="text-xs font-semibold text-gray-400 w-10">14:42</span>
       </div>
       <div className="flex items-center justify-center gap-8">
          <button className="text-gray-800 hover:text-blue-600 transition-colors relative group">
            <SkipBack className="w-8 h-8" strokeWidth={1.5} />
            <span className="absolute -bottom-3 left-1/2 -translate-x-1/2 text-[10px] font-bold group-hover:text-blue-600 text-gray-500">15</span>
          </button>
          <button 
             onClick={() => setIsPlaying(!isPlaying)}
             className="w-20 h-20 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/30 active:scale-95"
          >
             {isPlaying ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
          </button>
          <button className="text-gray-800 hover:text-blue-600 transition-colors relative group">
            <SkipForward className="w-8 h-8" strokeWidth={1.5} />
            <span className="absolute -bottom-3 left-1/2 -translate-x-1/2 text-[10px] font-bold group-hover:text-blue-600 text-gray-500">15</span>
          </button>
       </div>
    </div>
  </div>
);

const ScanView = () => (
  <div className="h-full bg-black flex flex-col relative pt-8">
    {/* Camera Header */}
    <div className="flex justify-between items-center p-6 text-white absolute top-8 w-full z-10">
      <button className="p-2 bg-black/40 backdrop-blur-md rounded-full"><Zap className="w-5 h-5" /></button>
      <span className="bg-black/60 px-4 py-1.5 rounded-full text-xs font-bold tracking-wide backdrop-blur-md text-yellow-400 border border-yellow-400/30">Auto Scan</span>
      <button className="p-2 bg-black/40 backdrop-blur-md rounded-full"><Maximize className="w-5 h-5" /></button>
    </div>

    {/* Viewfinder Guide */}
    <div className="flex-1 flex items-center justify-center p-8 relative">
      <div className="absolute inset-0 opacity-50 bg-[url('https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center blur-sm saturate-50"></div>
      <div className="absolute inset-0 bg-black/40"></div>
      
      {/* Target Frame */}
      <div className="w-full max-w-[280px] h-[400px] border border-white/20 rounded-xl relative z-10 shadow-[0_0_0_9999px_rgba(0,0,0,0.4)]">
        <div className="absolute -top-1 -left-1 w-12 h-12 border-t-4 border-l-4 border-yellow-400 rounded-tl-xl"></div>
        <div className="absolute -top-1 -right-1 w-12 h-12 border-t-4 border-r-4 border-yellow-400 rounded-tr-xl"></div>
        <div className="absolute -bottom-1 -left-1 w-12 h-12 border-b-4 border-l-4 border-yellow-400 rounded-bl-xl"></div>
        <div className="absolute -bottom-1 -right-1 w-12 h-12 border-b-4 border-r-4 border-yellow-400 rounded-br-xl"></div>
        
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
           <p className="text-white text-sm font-semibold bg-black/60 px-5 py-2.5 rounded-full backdrop-blur-md shadow-lg animate-pulse">Position text in frame</p>
        </div>
      </div>
    </div>

    {/* Controls */}
    <div className="pb-10 pt-6 px-10 flex justify-between items-center bg-black/90 backdrop-blur-lg relative z-10">
      <button className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-white hover:bg-gray-700 transition-colors">
        <ImageIcon className="w-5 h-5" />
      </button>
      
      <button className="w-20 h-20 rounded-full border-[5px] border-white flex items-center justify-center p-1 group active:scale-95 transition-transform">
        <div className="w-full h-full bg-white rounded-full group-hover:scale-95 transition-transform duration-200 shadow-inner"></div>
      </button>

      <button className="w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center text-white hover:bg-gray-700 transition-colors">
        <Settings className="w-5 h-5" />
      </button>
    </div>
  </div>
);

const SettingsView = ({ speed, setSpeed }: any) => (
  <div className="h-full bg-gray-50 flex flex-col overflow-y-auto pt-8">
    <div className="p-6 pt-8 pb-32">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Settings</h2>
      
      {/* Playback Settings */}
      <div className="mb-8">
        <h3 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-3 px-3">Voice & Playback</h3>
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100/50">
          
          <div className="mb-6">
            <div className="flex justify-between items-end mb-4">
              <label className="font-semibold text-gray-800">Reading Speed</label>
              <span className="text-blue-600 font-bold text-lg bg-blue-50 px-3 py-1 rounded-lg">{speed}x</span>
            </div>
            <input 
              type="range" min="0.5" max="3" step="0.1" 
              value={speed}
              onChange={(e) => setSpeed(parseFloat(e.target.value))}
              className="w-full h-2.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-200" 
            />
            <div className="flex justify-between text-xs text-gray-400 mt-3 font-semibold px-1">
              <span>0.5x</span>
              <span>1.0x</span>
              <span>2.0x</span>
              <span>3.0x</span>
            </div>
          </div>

          <div className="h-px bg-gray-100 w-full mb-6"></div>

          <div className="mb-6">
            <div className="flex justify-between items-end mb-4">
              <label className="font-semibold text-gray-800">Voice Pitch</label>
              <span className="text-blue-600 font-bold text-sm bg-blue-50 px-3 py-1 rounded-lg">Standard</span>
            </div>
            <input type="range" className="w-full h-2.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600" />
          </div>

          <div className="h-px bg-gray-100 w-full mb-6"></div>

          <div>
            <div className="flex justify-between items-end mb-4">
              <label className="font-semibold text-gray-800">Volume</label>
            </div>
            <div className="flex items-center gap-4">
              <Volume2 className="text-gray-400 w-6 h-6" />
              <input type="range" className="flex-1 h-2.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600" />
            </div>
          </div>

        </div>
      </div>

      {/* Language Settings */}
      <div className="mb-8">
        <h3 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-3 px-3">Language & Voice (40+ Supported)</h3>
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100/50 overflow-hidden">
          <button className="w-full flex justify-between items-center p-4 hover:bg-gray-50 transition-colors text-left group">
            <div>
              <p className="font-bold text-gray-800">Language</p>
              <p className="text-sm text-gray-500 mt-0.5">English, Chinese, French...</p>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-300 group-hover:text-blue-500 rotate-180 transition-colors" />
          </button>
          <div className="h-px bg-gray-100 w-full ml-4"></div>
          <button className="w-full flex justify-between items-center p-4 hover:bg-gray-50 transition-colors text-left group">
            <div>
              <p className="font-bold text-gray-800">Selected Voice</p>
              <p className="text-sm text-gray-500 mt-0.5 text-blue-600">Samantha (Enhanced)</p>
            </div>
            <ChevronLeft className="w-5 h-5 text-gray-300 group-hover:text-blue-500 rotate-180 transition-colors" />
          </button>
        </div>
      </div>
      
    </div>
  </div>
);

const LibraryView = () => {
  const books = [
    { title: "A Scandal in Bohemia", author: "Arthur Conan Doyle", progress: 12, cover: "bg-orange-100 text-orange-600" },
    { title: "The Art of War", author: "Sun Tzu", progress: 45, cover: "bg-blue-100 text-blue-600" },
    { title: "Web Article: Future of AI", author: "TechCrunch", progress: 0, cover: "bg-emerald-100 text-emerald-600" },
    { title: "Alice in Wonderland", author: "Lewis Carroll", progress: 89, cover: "bg-purple-100 text-purple-600" },
  ];

  return (
    <div className="h-full bg-[#f8fafc] flex flex-col relative pt-8">
      <div className="p-6 pt-6 pb-4 flex justify-between items-center z-10 relative">
        <h2 className="text-3xl font-bold text-gray-900">Library</h2>
        <button className="w-11 h-11 bg-blue-600 text-white shadow-lg shadow-blue-600/30 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors active:scale-95">
          <Plus className="w-6 h-6" />
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto px-6 pb-32">
        {/* Cloud sync banner */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-5 mb-6 text-white flex items-center justify-between shadow-lg shadow-blue-600/20">
          <div>
            <h4 className="font-bold mb-1 flex items-center gap-2">
              iCloud Sync Active
            </h4>
            <p className="text-xs text-blue-100 font-medium">Files shared across iPad & Mac</p>
          </div>
          <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md">
            <Zap className="w-5 h-5 text-yellow-300 fill-current" />
          </div>
        </div>

        <h3 className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-4 px-2">Recent Documents</h3>

        <div className="grid gap-4">
          {books.map((book, idx) => (
            <div key={idx} className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100/50 flex gap-4 items-center cursor-pointer hover:border-blue-200 hover:shadow-md transition-all group">
              <div className={`w-14 h-16 rounded-xl flex items-center justify-center font-serif text-2xl font-bold ${book.cover} group-hover:scale-105 transition-transform`}>
                {book.title[0]}
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-gray-800 line-clamp-1 group-hover:text-blue-600 transition-colors">{book.title}</h4>
                <p className="text-xs font-semibold text-gray-400 mb-3 mt-0.5">{book.author}</p>
                <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${book.progress}%` }}></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
